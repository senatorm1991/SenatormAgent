package com.senatorm.agent

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "agent_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun load(): AgentSettings {
        val d = AgentSettings()
        fun g(k: String, def: String) = prefs.getString(k, def) ?: def
        return AgentSettings(
            g("apiKey", ""), g("baseUrl", d.baseUrl), g("model", d.model),
            g("ghToken", ""), g("owner", ""), g("repo", ""),
            g("baseBranch", d.baseBranch), g("workBranch", d.workBranch),
        )
    }

    fun save(s: AgentSettings) = prefs.edit()
        .putString("apiKey", s.apiKey.trim()).putString("baseUrl", s.baseUrl.trim())
        .putString("model", s.model.trim()).putString("ghToken", s.ghToken.trim())
        .putString("owner", s.owner.trim()).putString("repo", s.repo.trim())
        .putString("baseBranch", s.baseBranch.trim()).putString("workBranch", s.workBranch.trim())
        .apply()
}
