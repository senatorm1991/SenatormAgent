package com.senatorm.agent.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val Ink = Color(0xFF0E1116)
    val Panel = Color(0xFF171C24)
    val Panel2 = Color(0xFF1F2632)
    val Line = Color(0xFF2A323F)
    val Text = Color(0xFFE8E6E1)
    val Dim = Color(0xFF8B93A1)
    val Amber = Color(0xFFFFB454)
    val Mint = Color(0xFF6EE7B7)
    val Coral = Color(0xFFFF7A7A)
}

@Composable
fun AgentTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = C.Amber, onPrimary = C.Ink,
        background = C.Ink, onBackground = C.Text,
        surface = C.Panel, onSurface = C.Text,
        surfaceVariant = C.Panel2, onSurfaceVariant = C.Dim,
        error = C.Coral, outline = C.Line,
    ),
    content = content,
)
