package com.senatorm.agent.agent

import android.util.Base64
import com.senatorm.agent.AgentSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FilterInputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

data class Run(val id: Long, val conclusion: String?, val url: String)

class GitHub(private val s: AgentSettings) {
    private val http = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
    private val base = "https://api.github.com/repos/${s.owner}/${s.repo}"

    private suspend fun call(method: String, path: String, body: JSONObject? = null): String =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url(if (path.startsWith("http")) path else base + path)
                .header("Authorization", "Bearer ${s.ghToken}")
                .header("Accept", "application/vnd.github+json")
                .header("X-GitHub-Api-Version", "2022-11-28")
                .method(method, body?.toString()?.toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("GitHub ${r.code}: ${txt.take(300)}")
                txt
            }
        }

    /** Returns the head SHA of the work branch, creating it from the base branch if missing. */
    suspend fun ensureBranch(): String = try {
        JSONObject(call("GET", "/git/ref/heads/${s.workBranch}")).getJSONObject("object").getString("sha")
    } catch (e: Exception) {
        if (e.message?.contains("404") != true) throw e
        val sha = JSONObject(call("GET", "/git/ref/heads/${s.baseBranch}")).getJSONObject("object").getString("sha")
        call("POST", "/git/refs", JSONObject().put("ref", "refs/heads/${s.workBranch}").put("sha", sha))
        sha
    }

    suspend fun listFiles(): List<String> {
        ensureBranch()
        val arr = JSONObject(call("GET", "/git/trees/${s.workBranch}?recursive=1")).getJSONArray("tree")
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.getString("type") == "blob" }.map { it.getString("path") }
    }

    suspend fun readFile(path: String): String {
        ensureBranch()
        val j = JSONObject(call("GET", "/contents/${android.net.Uri.encode(path, "/")}?ref=${s.workBranch}"))
        return String(Base64.decode(j.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
    }

    /** One atomic commit for all changes. A null value deletes the file. */
    suspend fun commit(changes: Map<String, String?>, message: String): String {
        val head = ensureBranch()
        val baseTree = JSONObject(call("GET", "/git/commits/$head")).getJSONObject("tree").getString("sha")
        val tree = JSONArray()
        for ((path, content) in changes) {
            val e = JSONObject().put("path", path).put("mode", "100644").put("type", "blob")
            if (content == null) e.put("sha", JSONObject.NULL) else {
                val blob = JSONObject(call("POST", "/git/blobs",
                    JSONObject().put("content", content).put("encoding", "utf-8")))
                e.put("sha", blob.getString("sha"))
            }
            tree.put(e)
        }
        val newTree = JSONObject(call("POST", "/git/trees",
            JSONObject().put("base_tree", baseTree).put("tree", tree))).getString("sha")
        val commit = JSONObject(call("POST", "/git/commits", JSONObject()
            .put("message", message).put("tree", newTree).put("parents", JSONArray().put(head)))).getString("sha")
        call("PATCH", "/git/refs/heads/${s.workBranch}", JSONObject().put("sha", commit))
        return commit
    }

    /** Polls until every workflow run for this commit has finished (or timeout). */
    suspend fun waitForRun(sha: String, timeoutMs: Long = 420_000): Run? {
        val end = System.currentTimeMillis() + timeoutMs
        delay(8_000)
        while (System.currentTimeMillis() < end) {
            val arr = JSONObject(call("GET", "/actions/runs?head_sha=$sha&per_page=10")).getJSONArray("workflow_runs")
            val runs = (0 until arr.length()).map { arr.getJSONObject(it) }
            if (runs.isNotEmpty() && runs.all { it.getString("status") == "completed" }) {
                val r = runs.firstOrNull { it.optString("conclusion") != "success" } ?: runs.first()
                return Run(r.getLong("id"), if (r.isNull("conclusion")) null else r.getString("conclusion"), r.getString("html_url"))
            }
            delay(10_000)
        }
        return null
    }

    /** Downloads the run's first non-expired artifact and extracts the .apk from it into [dest]. */
    suspend fun downloadApk(runId: Long, dest: File, onProgress: (Float) -> Unit): File = withContext(Dispatchers.IO) {
        val arts = JSONObject(call("GET", "/actions/runs/$runId/artifacts")).getJSONArray("artifacts")
        val art = (0 until arts.length()).map { arts.getJSONObject(it) }
            .firstOrNull { !it.getBoolean("expired") } ?: error("artifact این build پیدا نشد (شاید منقضی شده)")
        val total = art.getLong("size_in_bytes").coerceAtLeast(1)
        val req = Request.Builder().url(art.getString("archive_download_url"))
            .header("Authorization", "Bearer ${s.ghToken}")
            .header("Accept", "application/vnd.github+json").build()
        http.newBuilder().callTimeout(0, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
            .newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("GitHub ${r.code}")
                var read = 0L
                val counting = object : FilterInputStream(r.body!!.byteStream()) {
                    override fun read(b: ByteArray, off: Int, len: Int): Int {
                        val n = super.read(b, off, len)
                        if (n > 0) { read += n; onProgress((read.toFloat() / total).coerceAtMost(1f)) }
                        return n
                    }
                }
                dest.parentFile?.mkdirs()
                var found = false
                ZipInputStream(counting).use { zip ->
                    while (!found) {
                        val e = zip.nextEntry ?: break
                        if (e.name.endsWith(".apk")) {
                            dest.outputStream().use { zip.copyTo(it) }
                            found = true
                        }
                    }
                }
                if (!found) error("فایل APK داخل artifact نبود")
                dest
            }
    }

    suspend fun failedLogs(runId: Long): String {
        val jobs = JSONObject(call("GET", "/actions/runs/$runId/jobs")).getJSONArray("jobs")
        val sb = StringBuilder()
        for (i in 0 until jobs.length()) {
            val job = jobs.getJSONObject(i)
            if (job.optString("conclusion") != "failure") continue
            val lines = call("GET", "/actions/jobs/${job.getLong("id")}/logs").lines()
            val errs = lines.filter { Regex("(^|\\s)e: |error:|FAILED|What went wrong|Caused by").containsMatchIn(it) }
            sb.append("== ${job.getString("name")} ==\n")
                .append(errs.take(40).joinToString("\n")).append("\n--- tail ---\n")
                .append(lines.takeLast(25).joinToString("\n")).append("\n")
        }
        return sb.toString().ifBlank { "no failed job logs found" }.takeLast(7000)
    }
}
