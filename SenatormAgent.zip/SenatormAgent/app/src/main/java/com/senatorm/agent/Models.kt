package com.senatorm.agent

enum class Role { USER, ASSISTANT, TOOL, APPROVAL, ERROR, APK }
enum class ToolState { RUNNING, OK, FAILED }

data class UiMessage(
    val id: Long,
    val role: Role,
    val text: String = "",
    val toolName: String = "",
    val toolState: ToolState = ToolState.RUNNING,
    val files: List<String> = emptyList(),
    val approved: Boolean? = null,
)

sealed interface AgentEvent {
    data class TextDelta(val text: String) : AgentEvent
    object TextEnd : AgentEvent
    data class ToolStart(val callId: String, val name: String, val summary: String) : AgentEvent
    data class ToolEnd(val callId: String, val ok: Boolean, val preview: String) : AgentEvent
    data class Error(val message: String) : AgentEvent
}

data class AgentSettings(
    val apiKey: String = "",
    val baseUrl: String = "https://api.anthropic.com",
    val model: String = "claude-sonnet-5-5",
    val ghToken: String = "",
    val owner: String = "",
    val repo: String = "",
    val baseBranch: String = "main",
    val workBranch: String = "agent/work",
) {
    val ready get() = apiKey.isNotBlank() && ghToken.isNotBlank() && owner.isNotBlank() && repo.isNotBlank()
}
