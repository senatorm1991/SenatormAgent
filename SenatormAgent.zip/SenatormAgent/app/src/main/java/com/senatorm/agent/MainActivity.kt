package com.senatorm.agent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.senatorm.agent.ui.*

private enum class Screen { CHAT, SETTINGS, HISTORY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AgentTheme {
                val vm: AgentViewModel = viewModel()
                var screen by remember { mutableStateOf(if (vm.settings.ready) Screen.CHAT else Screen.SETTINGS) }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    when (screen) {
                        Screen.SETTINGS -> SettingsScreen(vm) { screen = Screen.CHAT }
                        Screen.HISTORY -> HistoryScreen(vm, onOpen = { screen = Screen.CHAT }, onClose = { screen = Screen.CHAT })
                        Screen.CHAT -> ChatScreen(vm, onSettings = { screen = Screen.SETTINGS }, onHistory = { screen = Screen.HISTORY })
                    }
                }
            }
        }
    }
}
