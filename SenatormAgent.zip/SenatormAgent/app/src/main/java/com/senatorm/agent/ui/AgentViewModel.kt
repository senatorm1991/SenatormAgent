package com.senatorm.agent.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.senatorm.agent.*
import com.senatorm.agent.agent.AgentLoop
import com.senatorm.agent.agent.GitHub
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.util.UUID

class AgentViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SecureStore(app)
    private val chatStore = ChatStore(app)
    var settings by mutableStateOf(store.load()); private set
    val messages = mutableStateListOf<UiMessage>()
    val chats = mutableStateListOf<ChatStore.Meta>()
    var running by mutableStateOf(false); private set
    val downloading = mutableStateMapOf<Long, Float>()   // runId -> progress 0..1
    private val filesDir: File = app.filesDir

    private var chatId = UUID.randomUUID().toString()
    private var savedHistory = JSONArray()
    private var savedSha: String? = null
    private var agent: AgentLoop? = null
    private var job: Job? = null
    private var pending: CompletableDeferred<Boolean>? = null
    private var nextId = 0L
    private var streamId: Long? = null
    private val toolIds = HashMap<String, Long>()

    init { chatStore.list().firstOrNull()?.let { openChat(it.id) } }

    fun saveSettings(s: AgentSettings) {
        savedSha = agent?.lastSha ?: savedSha
        store.save(s); settings = s; agent = null
    }

    fun newChat() {
        if (running) return
        chatId = UUID.randomUUID().toString()
        messages.clear(); savedHistory = JSONArray(); savedSha = null
        agent = null; streamId = null; toolIds.clear()
    }

    fun openChat(id: String) {
        if (running) return
        val l = chatStore.load(id) ?: return
        chatId = id
        messages.clear(); messages.addAll(l.messages)
        nextId = (l.messages.maxOfOrNull { it.id } ?: -1) + 1
        savedHistory = l.history; savedSha = l.lastSha
        agent = null; streamId = null; toolIds.clear()
    }

    fun refreshChats() { chats.clear(); chats.addAll(chatStore.list()) }

    fun deleteChat(id: String) {
        chatStore.delete(id)
        if (id == chatId && !running) newChat()
        refreshChats()
    }

    fun send(text: String) {
        if (running || text.isBlank() || !settings.ready) return
        messages += UiMessage(nextId++, Role.USER, text.trim())
        running = true
        val a = agent ?: AgentLoop(settings, ::requestApproval, savedHistory, savedSha, ::onBuildReady).also { agent = it }
        job = viewModelScope.launch {
            try { a.run(text.trim(), ::handle) }
            finally {
                running = false
                streamId = null
                pending?.complete(false); pending = null
                for (i in messages.indices)
                    if (messages[i].role == Role.TOOL && messages[i].toolState == ToolState.RUNNING)
                        messages[i] = messages[i].copy(toolState = ToolState.FAILED)
                persist()
            }
        }
    }

    fun stop() { job?.cancel() }

    fun apkFile(runId: Long) = File(filesDir, "apks/$runId.apk")

    private fun onBuildReady(runId: Long, url: String) {
        messages += UiMessage(nextId++, Role.APK, runId.toString(), files = listOf(url))
    }

    fun downloadApk(runId: Long) {
        if (downloading.containsKey(runId)) return
        downloading[runId] = 0f
        viewModelScope.launch {
            try {
                GitHub(settings).downloadApk(runId, apkFile(runId)) { downloading[runId] = it }
            } catch (e: Exception) {
                apkFile(runId).delete()
                messages += UiMessage(nextId++, Role.ERROR, "دانلود APK ناموفق بود: ${e.message}")
            } finally {
                downloading.remove(runId)
            }
        }
    }

    fun decide(ok: Boolean) { pending?.complete(ok); pending = null }

    private fun persist() {
        val first = messages.firstOrNull { it.role == Role.USER } ?: return
        chatStore.save(chatId, first.text.take(40), messages.toList(), savedHistory, agent?.lastSha ?: savedSha)
    }

    private suspend fun requestApproval(msg: String, files: List<String>): Boolean {
        val d = CompletableDeferred<Boolean>()
        val id = nextId++
        messages += UiMessage(id, Role.APPROVAL, msg, files = files)
        pending = d
        val ok = d.await()
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(approved = ok)
        return ok
    }

    private fun handle(ev: AgentEvent) {
        when (ev) {
            is AgentEvent.TextDelta -> {
                val sid = streamId
                if (sid == null) {
                    val id = nextId++
                    streamId = id
                    messages += UiMessage(id, Role.ASSISTANT, ev.text)
                } else {
                    val i = messages.indexOfLast { it.id == sid }
                    if (i >= 0) messages[i] = messages[i].copy(text = messages[i].text + ev.text)
                }
            }
            AgentEvent.TextEnd -> streamId = null
            is AgentEvent.ToolStart -> {
                val id = nextId++
                toolIds[ev.callId] = id
                messages += UiMessage(id, Role.TOOL, ev.summary, toolName = ev.name)
            }
            is AgentEvent.ToolEnd -> {
                val i = messages.indexOfFirst { it.id == toolIds[ev.callId] }
                if (i >= 0) messages[i] = messages[i].copy(
                    toolState = if (ev.ok) ToolState.OK else ToolState.FAILED,
                    files = listOf(ev.preview),
                )
            }
            is AgentEvent.Error -> messages += UiMessage(nextId++, Role.ERROR, ev.message)
        }
    }
}
