package com.senatorm.agent.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "همین الان"
        m < 60 -> "$m دقیقه پیش"
        m < 1440 -> "${m / 60} ساعت پیش"
        else -> "${m / 1440} روز پیش"
    }
}

@Composable
fun HistoryScreen(vm: AgentViewModel, onOpen: () -> Unit, onClose: () -> Unit) {
    LaunchedEffect(Unit) { vm.refreshChats() }
    Column(Modifier.fillMaxSize().background(C.Ink).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("گفتگوهای قبلی", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "بستن", tint = C.Dim) }
        }
        HorizontalDivider(color = C.Line)
        if (vm.chats.isEmpty()) {
            Text("هنوز گفتگویی ذخیره نشده. بعد از اولین دستور اینجا ظاهر می‌شه.",
                color = C.Dim, modifier = Modifier.padding(24.dp), lineHeight = 24.sp)
        } else LazyColumn {
            items(vm.chats, key = { it.id }) { c ->
                Row(Modifier.fillMaxWidth().clickable { vm.openChat(c.id); onOpen() }.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.title, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(ago(c.updated), fontSize = 12.sp, color = C.Dim)
                    }
                    TextButton(onClick = { vm.deleteChat(c.id) }) { Text("حذف", color = C.Coral) }
                }
                HorizontalDivider(color = C.Line)
            }
        }
    }
}
