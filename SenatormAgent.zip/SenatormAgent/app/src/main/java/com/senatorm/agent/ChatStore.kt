package com.senatorm.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ChatStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "chats").apply { mkdirs() }

    data class Meta(val id: String, val title: String, val updated: Long)
    data class Loaded(val messages: List<UiMessage>, val history: JSONArray, val lastSha: String?)

    fun list(): List<Meta> = dir.listFiles().orEmpty().mapNotNull {
        runCatching {
            val j = JSONObject(it.readText())
            Meta(j.getString("id"), j.getString("title"), j.getLong("updated"))
        }.getOrNull()
    }.sortedByDescending { it.updated }

    fun save(id: String, title: String, messages: List<UiMessage>, history: JSONArray, lastSha: String?) {
        val ms = JSONArray()
        messages.forEach { m ->
            ms.put(JSONObject().put("id", m.id).put("role", m.role.name).put("text", m.text)
                .put("toolName", m.toolName).put("toolState", m.toolState.name)
                .put("files", JSONArray(m.files)).apply { m.approved?.let { put("approved", it) } })
        }
        val j = JSONObject().put("id", id).put("title", title).put("updated", System.currentTimeMillis())
            .put("messages", ms).put("history", history)
        lastSha?.let { j.put("lastSha", it) }
        File(dir, "$id.json").writeText(j.toString())
    }

    fun load(id: String): Loaded? = runCatching {
        val j = JSONObject(File(dir, "$id.json").readText())
        val arr = j.getJSONArray("messages")
        val ms = (0 until arr.length()).map { arr.getJSONObject(it) }.map { o ->
            val role = Role.valueOf(o.getString("role"))
            val f = o.getJSONArray("files")
            UiMessage(
                o.getLong("id"), role, o.getString("text"), o.getString("toolName"),
                ToolState.valueOf(o.getString("toolState")), (0 until f.length()).map { f.getString(it) },
                if (o.has("approved")) o.getBoolean("approved") else if (role == Role.APPROVAL) false else null,
            )
        }
        Loaded(ms, j.getJSONArray("history"), if (j.has("lastSha")) j.getString("lastSha") else null)
    }.getOrNull()

    fun delete(id: String) { File(dir, "$id.json").delete() }
}
