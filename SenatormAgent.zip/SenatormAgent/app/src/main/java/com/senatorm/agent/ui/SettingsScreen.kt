package com.senatorm.agent.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: AgentViewModel, onDone: () -> Unit) {
    var s by remember { mutableStateOf(vm.settings) }
    Column(Modifier.fillMaxSize().background(C.Ink).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("تنظیمات", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (vm.settings.ready) IconButton(onClick = onDone) { Icon(Icons.Default.Close, "بستن", tint = C.Dim) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Section("Claude API", "آدرس پایه رو می‌تونید به پراکسی یا مسیر دیگه‌ای تغییر بدید.")
            Field("API key", s.apiKey, { s = s.copy(apiKey = it) }, secret = true)
            Field("Base URL", s.baseUrl, { s = s.copy(baseUrl = it) })
            Field("Model", s.model, { s = s.copy(model = it) })
            Spacer(Modifier.height(8.dp))
            Section("GitHub", "توکن fine-grained با دسترسی Contents: Read and write و Actions: Read.")
            Field("Token", s.ghToken, { s = s.copy(ghToken = it) }, secret = true)
            Field("Owner", s.owner, { s = s.copy(owner = it) })
            Field("Repository", s.repo, { s = s.copy(repo = it) })
            Field("Base branch", s.baseBranch, { s = s.copy(baseBranch = it) })
            Field("Agent branch", s.workBranch, { s = s.copy(workBranch = it) })
        }
        Button(
            onClick = { vm.saveSettings(s); onDone() }, enabled = s.ready,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
        ) { Text("ذخیره", fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun Section(title: String, hint: String) = Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = C.Amber)
    Text(hint, fontSize = 13.sp, color = C.Dim, lineHeight = 20.sp)
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false) =
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        textStyle = TextStyle(textDirection = TextDirection.Ltr),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = C.Amber, unfocusedBorderColor = C.Line, focusedLabelColor = C.Amber),
    )
