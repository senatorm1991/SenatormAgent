package com.senatorm.agent.agent

import com.senatorm.agent.AgentSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ClaudeClient(private val s: AgentSettings) {
    private val http = OkHttpClient.Builder()
        .callTimeout(0, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()

    /**
     * Streams a response (SSE). Text deltas go to [onText] on the main thread (batched ~50ms).
     * Returns {"content": [...], "stop_reason": "..."} assembled from the stream.
     */
    suspend fun stream(system: String, messages: JSONArray, tools: JSONArray, onText: (String) -> Unit): JSONObject =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("model", s.model).put("max_tokens", 8000).put("stream", true)
                .put("system", system).put("tools", tools).put("messages", messages)
            val req = Request.Builder().url(s.baseUrl.trimEnd('/') + "/v1/messages")
                .header("x-api-key", s.apiKey)
                .header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("Claude API ${r.code}: ${r.body?.string().orEmpty().take(300)}")
                val src = r.body!!.source()
                val blocks = HashMap<Int, JSONObject>()
                val bufs = HashMap<Int, StringBuilder>()
                val content = JSONArray()
                var stop: String? = null
                val pending = StringBuilder()
                var last = 0L
                suspend fun flush() {
                    if (pending.isEmpty()) return
                    val t = pending.toString(); pending.clear()
                    withContext(Dispatchers.Main) { onText(t) }
                }
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val ev = JSONObject(line.substring(5).trim())
                    when (ev.getString("type")) {
                        "content_block_start" -> {
                            val i = ev.getInt("index")
                            blocks[i] = ev.getJSONObject("content_block"); bufs[i] = StringBuilder()
                        }
                        "content_block_delta" -> {
                            val i = ev.getInt("index")
                            val d = ev.getJSONObject("delta")
                            when (d.getString("type")) {
                                "text_delta" -> {
                                    val t = d.getString("text")
                                    bufs[i]!!.append(t); pending.append(t)
                                    if (System.currentTimeMillis() - last > 50) { flush(); last = System.currentTimeMillis() }
                                }
                                "input_json_delta" -> bufs[i]!!.append(d.getString("partial_json"))
                            }
                        }
                        "content_block_stop" -> {
                            flush()
                            val i = ev.getInt("index")
                            val b = blocks[i]!!
                            val txt = bufs[i].toString()
                            when (b.getString("type")) {
                                "text" -> if (txt.isNotBlank()) content.put(JSONObject().put("type", "text").put("text", txt))
                                "tool_use" -> content.put(JSONObject().put("type", "tool_use")
                                    .put("id", b.getString("id")).put("name", b.getString("name"))
                                    .put("input", JSONObject(txt.ifBlank { "{}" })))
                            }
                        }
                        "message_delta" -> stop = ev.getJSONObject("delta").optString("stop_reason")
                        "error" -> error(ev.getJSONObject("error").optString("message", "stream error"))
                    }
                }
                flush()
                JSONObject().put("content", content).put("stop_reason", stop)
            }
        }
}
