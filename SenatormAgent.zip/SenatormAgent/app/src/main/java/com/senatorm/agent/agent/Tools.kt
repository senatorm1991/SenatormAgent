package com.senatorm.agent.agent

import org.json.JSONArray
import org.json.JSONObject

object Tools {
    private fun tool(name: String, desc: String, vararg params: Pair<String, String>) =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema", JSONObject().put("type", "object")
                .put("properties", JSONObject().apply {
                    params.forEach { (k, d) -> put(k, JSONObject().put("type", "string").put("description", d)) }
                })
                .put("required", JSONArray(params.map { it.first }))
        )

    fun schema(): JSONArray = JSONArray()
        .put(tool("list_files", "List all files in the repository (work branch, including staged changes)."))
        .put(tool("read_file", "Read one file's full text.", "path" to "File path relative to repo root"))
        .put(tool("write_file", "Create or overwrite a file with its FULL new content. Staged locally until commit_and_push.",
            "path" to "File path", "content" to "Complete new file content"))
        .put(tool("delete_file", "Delete a file (staged until commit_and_push).", "path" to "File path"))
        .put(tool("commit_and_push", "Commit all staged changes in one commit and push. The user must approve first.",
            "message" to "Short commit message"))
        .put(tool("get_build_status", "Wait for the GitHub Actions build of the last pushed commit. Returns success, or failure with error logs."))

    fun label(name: String) = when (name) {
        "list_files" -> "مرور فایل‌ها"
        "read_file" -> "خواندن"
        "write_file" -> "نوشتن"
        "delete_file" -> "حذف"
        "commit_and_push" -> "ارسال به GitHub"
        "get_build_status" -> "نتیجه build"
        else -> name
    }
}
