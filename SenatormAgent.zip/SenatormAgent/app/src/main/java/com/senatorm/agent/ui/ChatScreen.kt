package com.senatorm.agent.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.senatorm.agent.*
import com.senatorm.agent.agent.Tools
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext

@Composable
fun ChatScreen(vm: AgentViewModel, onSettings: () -> Unit, onHistory: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text?.length) {
        if (vm.messages.isNotEmpty()) {
            listState.scrollToItem(vm.messages.lastIndex)
            listState.scrollBy(1_000_000f)
        }
    }
    Column(
        Modifier.fillMaxSize().background(C.Ink)
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        TopBar(vm, onSettings, onHistory)
        Box(Modifier.weight(1f)) {
            if (vm.messages.isEmpty()) EmptyState(vm, onSettings)
            else LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            ) { items(vm.messages, key = { it.id }) { MessageItem(it, vm) } }
        }
        InputBar(vm)
    }
}

@Composable
private fun TopBar(vm: AgentViewModel, onSettings: () -> Unit, onHistory: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ایجنت کدنویس", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                if (vm.settings.ready) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${vm.settings.owner}/${vm.settings.repo}", fontSize = 11.sp,
                            color = C.Dim, fontFamily = FontFamily.Monospace)
                        Text(vm.settings.workBranch, fontSize = 11.sp, color = C.Amber, fontFamily = FontFamily.Monospace,
                            modifier = Modifier.border(1.dp, C.Line, RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 1.dp))
                    }
                }
            }
            if (vm.running) {
                val a by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
                    infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
                Box(Modifier.size(8.dp).alpha(a).background(C.Amber, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("در حال کار", fontSize = 12.sp, color = C.Amber)
            }
            TextButton(onClick = onHistory, enabled = !vm.running) { Text("تاریخچه", color = if (vm.running) C.Line else C.Dim) }
            IconButton(onClick = vm::newChat, enabled = !vm.running) { Icon(Icons.Default.Add, "گفتگوی جدید", tint = if (vm.running) C.Line else C.Dim) }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "تنظیمات", tint = C.Dim) }
        }
        HorizontalDivider(color = C.Line)
    }
}

@Composable
private fun EmptyState(vm: AgentViewModel, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("چه چیزی بسازیم؟", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("دستور بدید. ایجنت کد رو می‌خونه، تغییر می‌ده، روی GitHub می‌سازه و اگه build خطا داد خودش درستش می‌کنه.",
            color = C.Dim, fontSize = 15.sp, lineHeight = 24.sp)
        Spacer(Modifier.height(24.dp))
        if (!vm.settings.ready) {
            Button(onClick = onSettings, shape = RoundedCornerShape(12.dp)) { Text("تکمیل تنظیمات") }
        } else {
            listOf("یک دکمه خروجی اکسل به صفحه اصلی اضافه کن",
                "آخرین خطای build رو پیدا کن و درست کن",
                "ساختار پروژه رو توضیح بده").forEach {
                Text(it, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    .border(1.dp, C.Line, RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp)).clickable { vm.send(it) }.padding(14.dp))
            }
        }
    }
}

@Composable
private fun MessageItem(m: UiMessage, vm: AgentViewModel) = when (m.role) {
    Role.USER -> Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.CenterStart) {
        Text(m.text, fontSize = 15.sp, lineHeight = 23.sp,
            modifier = Modifier.widthIn(max = 300.dp)
                .background(C.Panel2, RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)).padding(14.dp, 10.dp))
    }
    Role.ASSISTANT -> SelectionContainer { Box(Modifier.padding(vertical = 8.dp)) { Markdownish(m.text) } }
    Role.TOOL -> ToolStep(m)
    Role.APPROVAL -> ApprovalCard(m, vm)
    Role.APK -> ApkCard(m, vm)
    Role.ERROR -> Text(m.text, color = C.Coral, fontSize = 14.sp, lineHeight = 22.sp,
        modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth()
            .border(1.dp, C.Coral.copy(alpha = .5f), RoundedCornerShape(12.dp)).padding(12.dp))
}

/** The timeline rail: consecutive tool calls read as one continuous process. */
@Composable
private fun ToolStep(m: UiMessage) {
    var open by remember { mutableStateOf(false) }
    val color = when (m.toolState) { ToolState.RUNNING -> C.Amber; ToolState.OK -> C.Mint; ToolState.FAILED -> C.Coral }
    val a by rememberInfiniteTransition(label = "n").animateFloat(0.35f, 1f,
        infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "a")
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clickable { open = !open }) {
        Box(Modifier.width(22.dp).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.fillMaxHeight().width(1.dp).background(C.Line))
            Box(Modifier.padding(top = 14.dp).size(10.dp)
                .alpha(if (m.toolState == ToolState.RUNNING) a else 1f).background(color, CircleShape))
        }
        Column(Modifier.padding(vertical = 8.dp).weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Tools.label(m.toolName), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = color)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(m.text, fontSize = 12.sp, color = C.Dim, fontFamily = FontFamily.Monospace,
                        maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                }
            }
            if (open && m.files.isNotEmpty()) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text(m.files.first(), fontSize = 11.sp, color = C.Dim, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 6.dp).fillMaxWidth()
                        .background(C.Panel, RoundedCornerShape(8.dp)).padding(10.dp))
            }
        }
    }
}

@Composable
private fun ApprovalCard(m: UiMessage, vm: AgentViewModel) {
    Column(Modifier.padding(vertical = 8.dp).fillMaxWidth()
        .border(1.dp, C.Amber.copy(alpha = .7f), RoundedCornerShape(14.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("تأیید برای ارسال به GitHub", color = C.Amber, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Text(m.text, fontSize = 14.sp, color = C.Text)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.clip(RoundedCornerShape(8.dp))) {
                m.files.forEach { f ->
                    val add = f.startsWith("+")
                    val c = if (add) C.Mint else C.Coral
                    Text(f, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = c,
                        modifier = Modifier.fillMaxWidth().background(c.copy(alpha = .09f)).padding(horizontal = 10.dp, vertical = 6.dp))
                }
            }
        }
        when (m.approved) {
            null -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.decide(true) }, shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) { Text("تأیید و Push") }
                OutlinedButton(onClick = { vm.decide(false) }, shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) { Text("رد") }
            }
            true -> Text("تأیید شد", color = C.Mint, fontSize = 13.sp)
            false -> Text("رد شد", color = C.Coral, fontSize = 13.sp)
        }
    }
}

@Composable
private fun ApkCard(m: UiMessage, vm: AgentViewModel) {
    val runId = m.text.toLongOrNull() ?: return
    val ctx = LocalContext.current
    val progress = vm.downloading[runId]
    val ready = progress == null && vm.apkFile(runId).exists()
    Column(Modifier.padding(vertical = 8.dp).fillMaxWidth()
        .border(1.dp, C.Mint.copy(alpha = .7f), RoundedCornerShape(14.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("APK آماده است", color = C.Mint, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        if (progress != null) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(),
                color = C.Mint, trackColor = C.Line)
            Text("در حال دانلود ${(progress * 100).toInt()}٪", fontSize = 13.sp, color = C.Dim)
        } else Button(
            onClick = { if (ready) installApk(ctx, vm.apkFile(runId)) else vm.downloadApk(runId) },
            shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = C.Mint, contentColor = C.Ink),
        ) { Text(if (ready) "نصب" else "دانلود APK", fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun Markdownish(text: String) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        text.split("```").forEachIndexed { i, part ->
            if (i % 2 == 0) {
                if (part.isNotBlank()) Text(part.trim(), fontSize = 15.sp, lineHeight = 24.sp)
            } else CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text(part.substringAfter('\n', part).trimEnd(), fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().background(C.Panel, RoundedCornerShape(8.dp))
                        .border(1.dp, C.Line, RoundedCornerShape(8.dp))
                        .horizontalScroll(rememberScrollState()).padding(12.dp))
            }
        }
    }
}

@Composable
private fun InputBar(vm: AgentViewModel) {
    var text by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            ?.let { text = (text + " " + it).trim() }
    }
    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Bottom) {
        TextField(
            value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
            placeholder = { Text("دستور بعدی…", color = C.Dim) }, maxLines = 5,
            shape = RoundedCornerShape(22.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = C.Panel, unfocusedContainerColor = C.Panel,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
        )
        IconButton(
            enabled = !vm.running, modifier = Modifier.size(52.dp),
            onClick = {
                try {
                    speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                        .putExtra(RecognizerIntent.EXTRA_PROMPT, "دستور رو بگید"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "تشخیص گفتار روی این گوشی در دسترس نیست", Toast.LENGTH_SHORT).show()
                }
            },
        ) { Text("🎤", fontSize = 20.sp) }
        FilledIconButton(
            onClick = { if (vm.running) vm.stop() else { vm.send(text); text = "" } },
            enabled = vm.running || (text.isNotBlank() && vm.settings.ready),
            modifier = Modifier.size(52.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = if (vm.running) C.Coral else C.Amber, contentColor = C.Ink,
                disabledContainerColor = C.Panel2, disabledContentColor = C.Dim),
        ) { Icon(if (vm.running) Icons.Default.Close else Icons.AutoMirrored.Filled.Send, if (vm.running) "توقف" else "ارسال") }
    }
}
