package com.senatorm.agent.agent

import com.senatorm.agent.AgentEvent
import com.senatorm.agent.AgentSettings
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject

class AgentLoop(
    private val s: AgentSettings,
    private val askApproval: suspend (message: String, files: List<String>) -> Boolean,
    val history: JSONArray = JSONArray(),
    var lastSha: String? = null,
    private val onBuildReady: (runId: Long, url: String) -> Unit = { _, _ -> },
) {
    private val claude = ClaudeClient(s)
    private val gh = GitHub(s)
    private val staged = LinkedHashMap<String, String?>()   // null value = delete
    private var commits = 0

    private val maxSteps = 30
    private val maxCommits = 4

    private val system = """
You are an Android/Kotlin coding agent working on the GitHub repo ${s.owner}/${s.repo} through tools. Work happens on branch ${s.workBranch}.
Reply in the user's language (Persian by default), briefly.
Rules:
1. Call list_files and read_file before editing. Never guess file contents.
2. Make minimal, focused changes. write_file takes the FULL new file content.
3. Nothing is pushed until commit_and_push, which asks the user for approval. Write a short commit message.
4. After a successful push call get_build_status. If the build fails, read the errors, fix the cause, and push again. You have at most $maxCommits pushes per task.
5. Finish with a short summary of what changed and the build result. Never print secrets. When a build succeeds the app itself shows a download and install button for the APK, so do not send the user to GitHub.
""".trimIndent()

    suspend fun run(userText: String, emit: (AgentEvent) -> Unit) {
        val mark = history.length()
        history.put(JSONObject().put("role", "user").put("content", userText))
        try {
            for (step in 0 until maxSteps) {
                val resp = claude.stream(system, history, Tools.schema()) { emit(AgentEvent.TextDelta(it)) }
                emit(AgentEvent.TextEnd)
                val content = resp.getJSONArray("content")
                if (content.length() == 0) return
                history.put(JSONObject().put("role", "assistant").put("content", content))
                val results = JSONArray()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    when (b.getString("type")) {
                        "tool_use" -> {
                            val id = b.getString("id")
                            val name = b.getString("name")
                            val input = b.getJSONObject("input")
                            emit(AgentEvent.ToolStart(id, name, input.optString("path").ifEmpty { input.optString("message") }))
                            var ok = true
                            val out = try { execute(name, input) } catch (e: CancellationException) { throw e }
                            catch (e: Exception) { ok = false; "ERROR: ${e.message}" }
                            emit(AgentEvent.ToolEnd(id, ok, out.take(300)))
                            results.put(JSONObject().put("type", "tool_result").put("tool_use_id", id)
                                .put("content", out.take(12000)).apply { if (!ok) put("is_error", true) })
                        }
                    }
                }
                if (results.length() == 0) return
                history.put(JSONObject().put("role", "user").put("content", results))
            }
            emit(AgentEvent.Error("به سقف مراحل رسیدم؛ ادامه بدم؟"))
        } catch (e: CancellationException) {
            rollback(mark); throw e
        } catch (e: Exception) {
            rollback(mark); emit(AgentEvent.Error(e.message ?: "خطای ناشناخته"))
        }
    }

    private fun rollback(mark: Int) {
        while (history.length() > mark) history.remove(history.length() - 1)
    }

    private suspend fun execute(name: String, i: JSONObject): String {
        when (name) {
            "list_files" -> {
                val set = gh.listFiles().toMutableSet()
                staged.forEach { (k, v) -> if (v == null) set.remove(k) else set.add(k) }
                return set.filter { f -> SKIP.none { f.startsWith(it) } && BINARY.none { f.endsWith(it) } }
                    .sorted().joinToString("\n")
            }
            "read_file" -> {
                val p = i.getString("path")
                if (staged.containsKey(p)) return staged[p] ?: "ERROR: file is staged for deletion"
                val t = gh.readFile(p)
                return if (t.length > 30000) t.take(30000) + "\n…[truncated]" else t
            }
            "write_file" -> {
                staged[i.getString("path")] = i.getString("content")
                return "staged ${i.getString("path")} (${i.getString("content").lines().size} lines)"
            }
            "delete_file" -> { staged[i.getString("path")] = null; return "staged deletion" }
            "commit_and_push" -> {
                if (staged.isEmpty()) return "nothing staged"
                if (commits >= maxCommits) return "ERROR: push limit reached. Stop and report to the user."
                val msg = i.getString("message")
                val files = staged.map { (p, c) -> (if (c == null) "−  " else "+  ") + p }
                if (!askApproval(msg, files)) return "USER REJECTED the changes. Staged changes are kept; ask what to change."
                val sha = gh.commit(LinkedHashMap(staged), msg)
                staged.clear(); commits++; lastSha = sha
                return "pushed ${sha.take(7)} to ${s.workBranch}. Call get_build_status next."
            }
            "get_build_status" -> {
                val sha = lastSha ?: return "ERROR: nothing pushed yet"
                val run = gh.waitForRun(sha) ?: return "Build still running after timeout. Tell the user."
                if (run.conclusion == "success") {
                    onBuildReady(run.id, run.url)
                    return "BUILD SUCCESS. The app now shows the user an APK download/install button."
                }
                return "BUILD ${run.conclusion}. ${run.url}\n" + gh.failedLogs(run.id)
            }
        }
        return "ERROR: unknown tool $name"
    }

    companion object {
        private val SKIP = listOf(".git/", "build/", ".gradle/", "app/build/")
        private val BINARY = listOf(".png", ".jpg", ".jpeg", ".webp", ".jar", ".apk", ".aab", ".ttf", ".otf", ".so", ".zip")
    }
}
