# ViewModel is created reflectively
-keep class com.senatorm.agent.ui.AgentViewModel { <init>(android.app.Application); }

# Optional dependencies referenced by OkHttp / Tink that are not on Android
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.j2objc.annotations.**
